<!-- <?php echo basename(__FILE__); ?>-->


<footer>
  <?php get_template_part('nav'); ?>
</footer>
<?php wp_footer(); ?>
</body>
</html>

<!-- <?php echo "END OF " . basename(__FILE__); ?>-->
