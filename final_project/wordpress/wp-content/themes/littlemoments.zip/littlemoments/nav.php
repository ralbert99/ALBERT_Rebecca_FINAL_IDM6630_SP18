<!-- <?php echo basename(__FILE__); ?>-->

<nav>
  <ul>
    <li><a href="#">Home</a></li>
    <li><a href="#">About</a></li>
    <li><a href="#">Wisdom</a></li>
    <li><a href="#">Wits</a></li>
  </ul>
</nav>

<!-- <?php echo "END OF " . basename(__FILE__); ?>-->
